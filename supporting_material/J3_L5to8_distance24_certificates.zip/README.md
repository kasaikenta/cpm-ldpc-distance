Classical binary full-CPM QC-LDPC distance-24 certificates.
Run python3 src/verify_best.py to check all stored result records, exact root/shard coverage, matrix ranks and weight-24 word syndromes.
This checks recorded computations; src/distance.cpp and data/*.cpm allow rerunning the searches.
Compile with g++ -O3 -std=c++17 -pthread src/distance.cpp -o distance.
Use classical mode, side X, max-weight 22, split-weight 5, and the root/shards/shard values in data/dfs_units.json for the desired case.
Every required shard must be complete. Timeout is not a distance certificate.
