from pathlib import Path
import json,hashlib,csv,zipfile
ROOT=Path(__file__).resolve().parents[1]
cases=json.loads((ROOT/'data/all_dfs_cases.json').read_text());units=json.loads((ROOT/'data/dfs_units.json').read_text());wanted={'baseline_L5_P45','desc2_L6_P71_r3','baseline_L7_P111','desc2_L8_P159_r6'};out=[]
for c in cases:
 if c['name'] not in wanted:continue
 P,L,E=c['P'],c['L'],c['E'];selected=[u for u in units if u['case']==c['name']];certs=[];states=0;elapsed=0
 for root in range(L):
  us=[u for u in selected if u['root']==root];assert us and {u['shard'] for u in us}==set(range(us[0]['shards']))
 for u in selected:
  f=ROOT/'results/remote/dfs'/('unit_%05d.result.json'%u['id']);d=json.loads(f.read_text())
  assert d['complete'] and not d['found'] and d['stabilizer_rows']==0
  assert (d['instance'],d['P'],d['base_columns'],d['mode'],d['max_weight'],d['root'],d['shard_count'],d['shard_index'])==(c['name'],P,L,'classical',22,u['root'],u['shards'],u['shard'])
  states+=d['stats']['states'];elapsed+=d['elapsed_sec'];certs.append(dict(file=str(f.relative_to(ROOT)),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
 rows=[0]*(3*P)
 for l in range(L):
  for t in range(P):
   for j in range(3):rows[j*P+(t+E[j][l])%P]|=1<<(t*L+l)
 assert all(r.bit_count()==L for r in rows)
 v=c['weight24_witness'];assert len(v)==len(set(v))==24;w=sum(1<<n for n in v);assert all((r&w).bit_count()%2==0 for r in rows)
 piv={}
 for r in rows:
  while r:
   h=r.bit_length()-1
   if h in piv:r^=piv[h]
   else:piv[h]=r;break
 out.append(dict(name=c['name'],J=3,L=L,P=P,E=E,n=P*L,k=P*L-len(piv),rank=len(piv),d=24,complete_shards=len(selected),search_states=states,sum_solver_elapsed_sec=elapsed,weight24_witness=v,certificates=certs,all_shard_coverage_and_metadata_verified=True,weight24_syndrome_verified=True,global_P_minimum_claimed=False))
out.sort(key=lambda r:r['L']);dest=ROOT/'results/best_verified.json';dest.write_text(json.dumps(out,indent=2)+'\n')
with (ROOT/'results/best_verified.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['J','L','P','n','k','d','E','complete_shards'])
 for r in out:w.writerow([r['J'],r['L'],r['P'],r['n'],r['k'],24,json.dumps(r['E']),r['complete_shards']])
with zipfile.ZipFile(ROOT/'results/J3_L5to8_distance24_certificates.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(dest,'results/best_verified.json');z.write(ROOT/'results/best_verified.csv','results/best_verified.csv');z.write(ROOT/'src/collect_verified.py','src/collect_verified.py');z.write(ROOT.parent/'minimum_lift/src/distance.cpp','src/distance.cpp');z.write(ROOT/'data/all_dfs_cases.json','data/all_dfs_cases.json');z.write(ROOT/'data/dfs_units.json','data/dfs_units.json')
 for r in out:
  for a in r['certificates']:z.write(ROOT/a['file'],a['file'])
  z.writestr('data/'+r['name']+'.cpm','CPM_CSS_V1\n'+f"{r['name']} {r['P']} {r['L']} 3 0\n"+'\n'.join(' '.join(map(str,row)) for row in r['E'])+'\n')
 z.writestr('README.md','Classical binary full-CPM QC-LDPC distance-24 certificates.\nRun python3 src/collect_verified.py to check all stored result records, exact root/shard coverage, matrix ranks and weight-24 word syndromes.\nThis checks recorded computations; src/distance.cpp and data/*.cpm allow rerunning the searches.\nCompile with g++ -O3 -std=c++17 -pthread src/distance.cpp -o distance.\nUse classical mode, side X, max-weight 22, split-weight 5, and the root/shards/shard values in data/dfs_units.json for the desired case.\nEvery required shard must be complete. Timeout is not a distance certificate.\n')
print([{k:r[k] for k in ['L','P','n','k','d','complete_shards','search_states']} for r in out])
