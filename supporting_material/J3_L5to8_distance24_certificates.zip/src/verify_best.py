"""Read-only verification of stored proof records, coverage, ranks, and witnesses."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for r in json.loads((ROOT/'results/best_verified.json').read_text()):
 P,L,E=r['P'],r['L'],r['E'];seen={i:set() for i in range(L)};counts={}
 for a in r['certificates']:
  f=ROOT/a['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==a['sha256'];d=json.loads(f.read_text())
  assert d['complete'] and not d['found'] and d['mode']=='classical' and d['stabilizer_rows']==0
  assert (d['instance'],d['P'],d['base_columns'],d['max_weight'])==(r['name'],P,L,22)
  root=d['root'];assert d['shard_index'] not in seen[root];seen[root].add(d['shard_index']);counts.setdefault(root,d['shard_count']);assert counts[root]==d['shard_count']
 assert all(seen[i]==set(range(counts[i])) for i in range(L))
 H=[0]*(3*P)
 for l in range(L):
  for t in range(P):
   for j in range(3):H[j*P+(t+E[j][l])%P]^=1<<(t*L+l)
 assert all(row.bit_count()==L for row in H);v=r['weight24_witness'];assert len(v)==len(set(v))==24;w=sum(1<<n for n in v);assert all((row&w).bit_count()%2==0 for row in H)
 piv={}
 for row in H:
  while row:
   bit=row.bit_length()-1
   if bit in piv:row^=piv[bit]
   else:piv[bit]=row;break
 assert len(piv)==r['rank'] and P*L-len(piv)==r['k'];print('Verified L=%d P=%d [%d,%d,24]'%(L,P,P*L,r['k']))
